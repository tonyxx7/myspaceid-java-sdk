/*
 * Copyright 2006-2008 Sxip Identity Corporation
 */

package org.openid4java.server;

/**
 * @author Marius Scurtescu, Johnny Bufu
 */
public interface NonceGenerator
{
    public String next();
}
